@extends('layouts.master')
@section('meta_title', 'Category Page')
@section('content')

    


<a href="{{route('home')}}">Back Home</a>





























@endsection
