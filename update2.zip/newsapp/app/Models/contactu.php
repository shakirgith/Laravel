<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class contactu extends Model
{
    use HasFactory;

    // for remove date or time collumn from database
    // public $timestamps = false; 
}
