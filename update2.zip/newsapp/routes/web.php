<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\TestingController;
use App\Http\Controllers\ContactsController;



Route::controller(PageController::class)->group (function(){

    Route::get('/', 'showHome')->name('home');
    Route::get('/category', 'showCategory')->name('category');
    Route::get('/contactus', 'showContactus')->name('contactus');

    // without group
    // Route::get('/user_info', [PageController::class, 'showUsers'])->name('users');

});


Route::controller(ContactsController::class)->group (function(){

    Route::get('/user_info', 'showContacts')->name('contactinfo');

    // by id number show info route
    Route::get('/user_info/{id}', 'singleContacts')->name('view.contactinfo');

    // update user data by id number route
    Route::put('/user_info/update/{id}', 'updateContacts')->name('update.contactinfo');

    //first find user id code for updating 
    Route::get('/user_info/updatepage/{id}', 'updatePage')->name('update.page');

    // delete user data by id number route
    Route::get('/user_info/delete/{id}', 'deleteContacts')->name('delete.contactinfo');

    Route::post('/contactus','addContacts')->name('addContacts');
    Route::view('newuser', '/contactus');

});





Route::get('/test', TestingController::class);



Route::fallback(function(){
    return view('notfound');
})->name('404_error_page');














