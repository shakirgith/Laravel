<?php $__env->startSection('meta_title', 'User Info Page'); ?>
<?php $__env->startSection('content'); ?>


<h2>User Contact us Details</h2>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $cotacts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($contacts->id); ?> |
    <?php echo e($contacts->user_name); ?> |
    <?php echo e($contacts->user_email); ?> |
    <?php echo e($contacts->user_subject); ?> |
    <?php echo e($contacts->user_message); ?> |
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/newsapp/resources/views/user_info.blade.php ENDPATH**/ ?>