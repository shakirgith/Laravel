<?php $__env->startSection('meta_title', 'Add Contact Query Page'); ?>
<?php $__env->startSection('content'); ?>
    


<div class="container-fluid mt-5 pt-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title mb-0">
                    <h4 class="m-0 text-uppercase font-weight-bold">Update Contact us Queries</h4>
                </div>
               
                    

                <form action="<?php echo e(route('update.contactinfo', $data->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control p-4" name="name" value="<?php echo e($data->user_name); ?>" placeholder="Your Name" required="required"/>
                                
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="email" class="form-control p-4" name="email" value="<?php echo e($data->user_email); ?>" placeholder="Your Email" required="required"/>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control p-4" name="subject" value="<?php echo e($data->user_subject); ?>" placeholder="Subject" required="required"/>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" rows="4" name="message" value="<?php echo e($data->user_message); ?>" placeholder="Message" required="required"></textarea>
                    </div>
                    <div>
                        <button class="btn btn-primary font-weight-semi-bold px-4" style="height: 50px;"
                            type="submit">Update</button>
                    </div>
                </form>
                
            </div>
            
        </div>
    </div>
</div>
<!-- Contact End -->



<?php $__env->stopSection(); ?>





























<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/newsapp/resources/views/updateuser.blade.php ENDPATH**/ ?>