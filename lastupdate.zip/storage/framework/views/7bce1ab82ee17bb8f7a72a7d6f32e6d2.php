<?php $__env->startSection('meta_title', 'User Info Page'); ?>
<?php $__env->startSection('content'); ?>


<h2>User Contact us Details</h2>
<div class="col-sm-8 mx-auto">
    <a href="/newuser">Add Query</a> 

    <?php if(session()->has('delmsg')): ?>
    <div class="alert alert-success">
    <?php echo e(session()->get('delmsg')); ?>

    </div>
    <?php endif; ?>


    <?php if(session('updatemsg')): ?>
    <div class="alert alert-success"><?php echo e(session('updatemsg')); ?></div>
    <?php endif; ?>

<div class="table-responsive">
<table class="table table-bordered table-striped">
<thead>
    <tr class="bg-dark">
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>File</th>
        <th>Message</th>
        <th>Created Date</th>
        <th>Action</th>
    </tr>
</thead>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $contacts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tbody>
    <tr>

        <td> <?php echo e($contacts->id); ?> </td>
        <td> <?php echo e($contacts->user_name); ?></td>
        <td> <?php echo e($contacts->user_email); ?></td>
        <td> <?php echo e($contacts->user_subject); ?></td>
        <td> <?php echo e($contacts->user_file); ?></td>
        <td> <?php echo e($contacts->user_message); ?> </td>
        <td> <?php echo e($contacts->created_at); ?> </td>
        <td> <a href="<?php echo e(route('view.contactinfo', $contacts->id)); ?>">View</a> 
            <a href="<?php echo e(route('update.page', $contacts->id)); ?>">Update</a> 
            <a href="<?php echo e(route('delete.contactinfo', $contacts->id)); ?>">Delete</a></td>

    </tr>
</tbody>
  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</table>
 <div class="pagination2">
        <?php echo e($data->links()); ?>

 </div>

<div class="currentPage1">
        Current Page: <?php echo e($data->currentPage()); ?> <br />
        Total Records: <?php echo e($data->total()); ?>

</div>


</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/newsapp/resources/views//user_info.blade.php ENDPATH**/ ?>