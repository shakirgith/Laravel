<?php



namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ContactsController extends Controller
{
    public function showContacts(){
         $cotacts = DB::table('contactus')->get();
        
        //  $cotacts = DB::table('contactus')
                        // ->select('user_name', 'user_email')

                        // change with column name and changes more 
                        // ->select('user_name as name', 'user_email')
                        // ->get();


         //by id number table show only
        // $cotacts = DB::table('contactus')->where('id', 10)->get();

        //direct show in browser
        // return $cotacts;

         //show in static file
        return view('/user_info', ['data' => $cotacts]);
    }

    // by id show contacts / user info code
    public function singleContacts(string $id){
        $singleUser = DB::table('contactus')->where('id', $id)->get();
        // return $cotacts;
        return view('/single_info', ['data' => $singleUser]);
    }

    // by id show contacts / user info code
    public function deleteContacts(string $id){
        $delUser = DB::table('contactus')
                      ->where('id', $id)
                      ->delete();
        
        // if($delUser){
        //     return redirect()-> route('user_info');
        // }
       
    }

     // Add User contact info on database contactus table with static/manual
    //  public function addContacts(){  
    //     $addUser = DB::table('contactus')
    //                         ->insert([
    //                             'user_name' => 'Sameer Khan',
    //                             'user_email' => 'sameerkhan@gmail.com',
    //                             'user_subject' => 'Sameer test subject',
    //                             'user_message' => 'test message for database',
    //                             'created_at' => now(),
    //                             'updated_at' => now()


    //                         ]);
    //   if($addUser){
    //     echo "<h2>Data Successfully Added</h2>";
    //   } else {
    //     echo "<h2>Sorry your data not updated</h2>";
    //   }


        // Add User contact info on database contactus table by Form
        public function addContacts(Request $req){
            $addUser = DB::table('contactus')
                                ->insert([
                                    'user_name' => $req-> name,
                                    'user_email' => $req-> email,
                                    'user_subject' => $req-> subject,
                                    'user_message' => $req-> message,
                                    'created_at' => now(),
                                    'updated_at' => now()
                                ]); 

        if($addUser){

            return redirect()->back()->with('msg', 'Data Successfully Added');
            // echo "<h4>Data Successfully Added</h4>"; 
        } else {
            return redirect()->back()->with('msg', 'Faileds while sending code!');
            // echo "<h4>Faileds while sending code!</h4>";
        }


        }



}
