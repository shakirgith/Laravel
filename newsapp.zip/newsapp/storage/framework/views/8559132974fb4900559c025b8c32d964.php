


<h2>Single User Details</h2>
<div class="col-sm-8 mx-auto">
<div class="table-responsive">
<table class="table table-bordered table-striped">
<thead>
    <tr class="bg-dark">
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Message</th>
        <th>Created Date</th>
    </tr>
</thead>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $singleUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tbody>
    <tr>

        <td> <?php echo e($singleUser->id); ?> </td>
        <td> <?php echo e($singleUser->user_name); ?></td>
        <td> <?php echo e($singleUser->user_email); ?></td>
        <td> <?php echo e($singleUser->user_subject); ?></td>
        <td> <?php echo e($singleUser->user_message); ?> </td>
        <td> <?php echo e($singleUser->created_at); ?> </td>
    </tr>
</tbody>
  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</table>
</div>
</div>


<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/newsapp/resources/views//single_info.blade.php ENDPATH**/ ?>