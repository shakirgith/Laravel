<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if (! empty(trim($__env->yieldContent('content')))): ?>
    <?php echo $__env->yieldContent('content'); ?>
<?php else: ?>
    <h1 class="heading-notfound">Page Content Not Found!</h1>
<?php endif; ?>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/newsapp/resources/views/layouts/master.blade.php ENDPATH**/ ?>