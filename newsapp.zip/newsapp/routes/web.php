<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\TestingController;
use App\Http\Controllers\ContactsController;



Route::controller(PageController::class)->group (function(){

    Route::get('/', 'showHome')->name('home');
    Route::get('/category', 'showCategory')->name('category');
    Route::get('/contactus', 'showContactus')->name('contactus');

    // without group
    // Route::get('/user_info', [PageController::class, 'showUsers'])->name('users');

});

Route::get('/user_info', [ContactsController::class, 'showContacts'])->name('contactinfo');
// by id number show info route
Route::get('/user_info/{id}', [ContactsController::class, 'singleContacts'])->name('view.contactinfo');

// delete user data by id number route
Route::get('/user_info/delete/{id}', [ContactsController::class, 'deleteContacts'])->name('delete.contactinfo');

Route::post('/newuser', [ContactsController::class, 'addContacts'])->name('addContacts');
Route::view('newuser', '/adduser');

Route::get('/test', TestingController::class);



Route::fallback(function(){
    return view('notfound');
})->name('404_error_page');














